package com.example.android.courtcounter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toast.makeText(MainActivity.this, "GAME HAS START", Toast.LENGTH_SHORT).show();
        displayForTeamA(scoreTeamA);
        displayForTeamB(scoreTeamB);


    }


     int scoreTeamA = 0;
     int scoreTeamB = 0;
     String Win = "Won";
     String loose = "Lost";


    /*
      +3 points method
     */
    public void addThreeForTeamA(View view){

        scoreTeamA = scoreTeamA + 3;
        displayForTeamA(scoreTeamA);
        if (scoreTeamA == 100 || scoreTeamA > 100){
            Toast.makeText(MainActivity.this, "TEAM A WON", Toast.LENGTH_LONG).show();
            scoreTeamA = 0;
            displayForTeamA(scoreTeamA);
            finalScoreA(Win);
            finalScoreB(loose);
        }
    }

    /*
      +2 points method
     */
    public void addTwoForTeamA(View view){
     scoreTeamA = scoreTeamA + 2;
     displayForTeamA(scoreTeamA);
        if (scoreTeamA == 100 || scoreTeamA > 100){
            Toast.makeText(MainActivity.this, "TEAM A WON", Toast.LENGTH_LONG).show();
            scoreTeamA = 0;
            displayForTeamA(scoreTeamA);
            finalScoreA(Win);
            finalScoreB(loose);
        }
    }
    /*
      Free throw
     */
    public void addOneForTeamA(View view){
        scoreTeamA = scoreTeamA + 1;
        displayForTeamA(scoreTeamA);
        if (scoreTeamA == 100 || scoreTeamA > 100){
            Toast.makeText(MainActivity.this, "TEAM A WON", Toast.LENGTH_LONG).show();
            scoreTeamA = 0;
            displayForTeamA(scoreTeamA);
            finalScoreA(Win);
            finalScoreB(loose);
        }

    }



    /**
     * Displays the given score for Team A.
     */
    public void displayForTeamA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText(String.valueOf(score));
    }
    public void finalScoreA(String results){
        TextView win = (TextView) findViewById(R.id.finalScoreA);
        win.setText(results);
    }

    /*Team B code


      +3 points method
     */
    public void addThreeForTeamB(View view){
        scoreTeamB = scoreTeamB + 3;
        displayForTeamB(scoreTeamB);
        if (scoreTeamB == 100 || scoreTeamB > 100){
            Toast.makeText(MainActivity.this, "TEAM B WON", Toast.LENGTH_LONG).show();
            scoreTeamB = 0;
            displayForTeamB(scoreTeamB);
            finalScoreB(Win);
            finalScoreA(loose);

        }
    }

    /*
      +2 points method
     */
    public void addTwoForTeamB(View view){
        scoreTeamB = scoreTeamB + 2;
        displayForTeamB(scoreTeamB);
        if (scoreTeamB == 100 || scoreTeamB > 100){
            Toast.makeText(MainActivity.this, "TEAM B WON", Toast.LENGTH_LONG).show();
            scoreTeamB = 0;
            displayForTeamB(scoreTeamB);
            finalScoreB(Win);
            finalScoreA(loose);
        }
    }
    /*
      Free throw
     */
    public void addOneForTeamB(View view){
        scoreTeamB = scoreTeamB + 1;
        displayForTeamB(scoreTeamB);
        if (scoreTeamB == 100 || scoreTeamB > 100){
            Toast.makeText(MainActivity.this, "TEAM B WON", Toast.LENGTH_LONG).show();
            scoreTeamB = 0;
            displayForTeamB(scoreTeamB);
            finalScoreB(Win);
            finalScoreA(loose);
        }

    }

    /**
     * Displays the given score for Team A.
     */
    public void displayForTeamB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText(String.valueOf(score));
    }
    // wining and loosing method
    public void finalScoreB(String results){
        TextView win = (TextView) findViewById(R.id.finalScoreB);
        win.setText(results);
    }

    // rest board code
    public void resetBoard(View view){
        scoreTeamA = 0;
        scoreTeamB = 0;
        String scoreForBothTeam = "Awaiting";
        finalScoreB(scoreForBothTeam);
        finalScoreA(scoreForBothTeam);
        displayForTeamA(scoreTeamA);
        displayForTeamB(scoreTeamB);

    }
}
